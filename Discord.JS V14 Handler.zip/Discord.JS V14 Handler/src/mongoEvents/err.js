module.exports = {
    name: 'err',
    async execute(error) {
    console.log(error);
    },
};